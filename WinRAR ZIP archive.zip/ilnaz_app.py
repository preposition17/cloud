from flask import Blueprint
from blueprint_io import IOBlueprint


ilnaz_app = Blueprint('ilnaz_app', __name__, template_folder='templates')
ilnaz_app_io = IOBlueprint('ilnaz_app_io', __name__)